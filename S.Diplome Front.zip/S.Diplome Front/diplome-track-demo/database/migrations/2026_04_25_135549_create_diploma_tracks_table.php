<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDiplomaTracksTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('diploma_tracks', function (Blueprint $table) {
            $table->id();
            $table->foreignId('diploma_id')->constrained()->onDelete('cascade');
            $table->enum('status', ['en cours', 'validé', 'délivré', 'annulé']);
            $table->string('mention')->nullable();
            $table->date('retrieval_date')->nullable();
            $table->text('comments')->nullable();
            $table->foreignId('user_id')->nullable()->comment('User who made the track')->constrained('users')->onDelete('set null');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('diploma_tracks');
    }
}
