<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/home', function () {
    return view('welcome');
})->name('app.home');

// Front-end complet (UI uniquement) — à brancher sur le backend plus tard.
Route::view('/login', 'student.login')->name('login');

// Pages transverses (UI)
Route::view('/settings', 'pages.settings')->name('app.settings');
Route::view('/support', 'pages.support')->name('app.support');

// Placeholder pages (UI) pour "Détails", etc.
Route::get('/p/{key}/{id?}', function (string $key, ?string $id = null) {
    $titles = [
        'student' => 'Détails étudiant',
        'diploma' => 'Détails diplôme',
        'tracking' => 'Détails suivi diplôme',
        'history' => 'Détails historique',
        'user' => 'Détails utilisateur',
        'role' => 'Détails rôle',
    ];

    return view('pages.placeholder', [
        'key' => $key,
        'id' => $id,
        'title' => $titles[$key] ?? 'Détails',
    ]);
})->name('app.placeholder');

// Étudiant
Route::view('/student/dashboard', 'student.dashboard')->name('student.dashboard');
Route::view('/student/history', 'student.history')->name('student.history');

// Administration
Route::view('/admin/students', 'admin.students.index')->name('admin.students.index');
Route::view('/admin/validation', 'admin.students.validation')->name('admin.students.validation');
Route::view('/admin/diplomas', 'admin.diplomas.index')->name('admin.diplomas.index');
Route::view('/admin/status', 'admin.diplomas.status')->name('admin.diplomas.status');

// Administrateur (SuperAdmin Unified)
Route::group(['prefix' => 'administrator'], function () {
    Route::view('/dashboard', 'admin.super-dashboard')->name('admin.super.dashboard');
    Route::view('/users', 'admin.users.index')->name('admin.users.index');
    Route::view('/roles', 'admin.roles.index')->name('admin.roles.index');
    Route::view('/profile', 'pages.profile')->name('admin.profile');
});
