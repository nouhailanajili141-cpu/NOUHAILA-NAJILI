<?php $__env->startSection('title', 'Gestion des Étudiants'); ?>

<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('partials.sidebar-generic', ['active' => 'admin.students'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="h3 mb-0 text-white fw-bold">Gestion des Étudiants</h2>
            <p class="text-muted">Consultez et gérez les dossiers des étudiants inscrits.</p>
        </div>
        <button class="btn btn-primary d-flex align-items-center gap-2 rounded-3 shadow-sm" data-bs-toggle="modal" data-bs-target="#addStudentModal">
            <i class="bi bi-person-plus-fill"></i> Ajouter un Étudiant
        </button>
    </div>

    <!-- Filtres -->
    <div class="card border-0 mb-4">
        <div class="card-body p-3">
            <form class="row g-3 align-items-end">
                <div class="col-md-3">
                    <label class="form-label small text-muted fw-bold">Recherche</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-search"></i></span>
                        <input type="text" class="form-control" placeholder="Nom, CNE ou Code Apogée">
                    </div>
                </div>
                <div class="col-md-3">
                    <label class="form-label small text-muted fw-bold">Filière</label>
                    <select class="form-select">
                        <option selected>Toutes les filières</option>
                        <option>Génie Logiciel</option>
                        <option>Réseaux & Sécurité</option>
                        <option>Intelligence Artificielle</option>
                    </select>
                </div>
                <div class="col-md-2">
                    <button type="button" class="btn btn-secondary w-100 rounded-3">Filtrer</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Table -->
    <div class="card border-0 shadow-sm rounded-4">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead>
                    <tr>
                        <th class="ps-4">Étudiant</th>
                        <th>Code Apogée</th>
                        <th>CNE</th>
                        <th>Filière</th>
                        <th>Statut</th>
                        <th class="text-end pe-4">Actions</th>
                    </tr>
                </thead>
                <tbody class="border-top-0">
                    <tr>
                        <td class="ps-4">
                            <div class="d-flex align-items-center">
                                <div class="bg-primary bg-opacity-10 text-primary rounded-circle d-flex justify-content-center align-items-center fw-bold me-3 text-white-force" style="width: 40px; height: 40px; background: rgba(var(--primary-rgb), 0.2) !important;">
                                    SB
                                </div>
                                <div>
                                    <div class="fw-bold text-white">Sara Benali</div>
                                    <div class="text-muted small">Réseaux & Télécoms</div>
                                </div>
                            </div>
                        </td>
                        <td class="text-white-force">19054321</td>
                        <td class="text-white-force">D987654321</td>
                        <td class="text-white-force">Réseaux & Télécoms</td>
                        <td><span class="badge bg-warning bg-opacity-10 text-warning rounded-pill px-3 py-2 border border-warning border-opacity-25">En cours</span></td>
                        <td class="text-end pe-4">
                            <button class="btn btn-sm btn-glass rounded-circle text-primary"><i class="bi bi-pencil"></i></button>
                            <button class="btn btn-sm btn-glass rounded-circle text-danger"><i class="bi bi-trash"></i></button>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="card-footer bg-transparent border-top border-white border-opacity-10 py-3">
            <nav aria-label="Page navigation">
                <ul class="pagination justify-content-center mb-0">
                    <li class="page-item disabled"><a class="page-link" href="#">Précédent</a></li>
                    <li class="page-item active"><a class="page-link" href="#">1</a></li>
                    <li class="page-item"><a class="page-link" href="#">2</a></li>
                    <li class="page-item"><a class="page-link" href="#">Suivant</a></li>
                </ul>
            </nav>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modals'); ?>
<!-- Modal Ajout Étudiant -->
<div class="modal fade" id="addStudentModal" tabindex="-1" style="z-index: 9999;">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content rounded-4 border-0 shadow-lg bg-dark text-light border border-white border-opacity-10">
            <div class="modal-header border-bottom border-white border-opacity-10 pb-3">
                <h5 class="modal-title fw-bold">Ajouter un Étudiant</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body p-4">
                <form>
                    <div class="row g-3">
                        <div class="col-md-6 mb-2">
                            <label class="form-label small fw-bold">Prénom</label>
                            <input type="text" class="form-control bg-white bg-opacity-5 border-white border-opacity-10" placeholder="Ex: Ahmed" required>
                        </div>
                        <div class="col-md-6 mb-2">
                            <label class="form-label small fw-bold">Nom</label>
                            <input type="text" class="form-control bg-white bg-opacity-5 border-white border-opacity-10" placeholder="Ex: Alami" required>
                        </div>
                        <div class="col-md-6 mb-2">
                            <label class="form-label small fw-bold">Code Apogée</label>
                            <input type="text" class="form-control bg-white bg-opacity-5 border-white border-opacity-10" placeholder="8 chiffres" required>
                        </div>
                        <div class="col-md-6 mb-2">
                            <label class="form-label small fw-bold">CNE</label>
                            <input type="text" class="form-control bg-white bg-opacity-5 border-white border-opacity-10" placeholder="Ex: R130..." required>
                        </div>
                        <div class="col-12">
                            <label class="form-label small fw-bold">Filière / Spécialité</label>
                            <select class="form-select bg-white bg-opacity-5 border-white border-opacity-10">
                                <option>Génie Logiciel</option>
                                <option>Réseaux & Sécurité</option>
                                <option>Intelligence Artificielle</option>
                            </select>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer border-top border-white border-opacity-10 pt-3 d-flex justify-content-between">
                <button type="button" class="btn btn-glass px-4" data-bs-dismiss="modal">Annuler</button>
                <button type="button" class="btn btn-primary px-4 shadow-lg">Enregistrer l'étudiant</button>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\pc\Desktop\S.Diplome Front\diplome-track-demo\resources\views/admin/students/index.blade.php ENDPATH**/ ?>