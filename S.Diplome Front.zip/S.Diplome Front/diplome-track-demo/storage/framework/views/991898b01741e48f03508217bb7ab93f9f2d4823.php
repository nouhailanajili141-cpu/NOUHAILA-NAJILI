

<?php $__env->startSection('title', 'Bienvenue | DiplômeTrack'); ?>

<?php $__env->startSection('content'); ?>
<div class="card auth-card shadow-lg border-0 overflow-hidden" style="max-width: 900px;">
    <div class="row g-0 h-100">
        <!-- Section Gauche : Branding -->
        <div class="col-lg-5 auth-left d-flex flex-column justify-content-between p-4 p-lg-5 text-white">
            <div>
                <div class="d-flex align-items-center gap-2 mb-5">
                    <div class="bg-white bg-opacity-20 p-2 rounded-3 text-white">
                        <i class="bi bi-gem h4 mb-0"></i>
                    </div>
                    <span class="fw-bold h4 mb-0" style="letter-spacing: 0.5px;">DiplômeTrack</span>
                </div>
                <h1 class="display-6 fw-bold mb-3">La gestion moderne des diplômes.</h1>
                <p class="opacity-75 lead">Simplifiez le cycle de vie académique, de la demande à la délivrance, pour les étudiants et l'administration.</p>
            </div>
            
            <div class="mt-4">
                <div class="d-flex align-items-center gap-3 mb-3 small opacity-80">
                    <div class="bg-white bg-opacity-10 p-2 rounded-circle"><i class="bi bi-shield-check"></i></div>
                    <span>Système Sécurisé & Certifié</span>
                </div>
                <div class="d-flex align-items-center gap-3 small opacity-80">
                    <div class="bg-white bg-opacity-10 p-2 rounded-circle"><i class="bi bi-lightning-charge"></i></div>
                    <span>Temps de Traitement Optimisé</span>
                </div>
            </div>
        </div>

        <!-- Section Droite : Actions -->
        <div class="col-lg-7 bg-white bg-opacity-5 auth-right text-light d-flex flex-column justify-content-center p-4 p-lg-5">
            <div class="mb-5">
                <h2 class="fw-bold mb-1 text-white">Accès Plateforme</h2>
                <p class="text-muted">Sélectionnez votre espace de connexion.</p>
            </div>

            <div class="row g-3">
                <div class="col-12">
                    <a href="<?php echo e(route('login')); ?>" class="btn list-group-item list-group-item-action p-4 border border-white border-opacity-10 rounded-3 d-flex align-items-center justify-content-between hover-lift">
                        <div class="d-flex align-items-center gap-4">
                            <div class="bg-primary bg-opacity-10 p-3 rounded-circle text-primary">
                                <i class="bi bi-box-arrow-in-right h4 mb-0"></i>
                            </div>
                            <div class="text-start">
                                <div class="fw-bold h5 mb-1 text-white">Portail d'Authentification</div>
                                <div class="small text-muted">Connexion via Code Apogée ou Identifiants Agents</div>
                            </div>
                        </div>
                        <i class="bi bi-chevron-right text-muted"></i>
                    </a>
                </div>

                <div class="col-md-6">
                    <a href="<?php echo e(route('student.dashboard')); ?>" class="btn list-group-item list-group-item-action p-4 border border-white border-opacity-10 rounded-3 text-center hover-lift h-100">
                        <div class="bg-success bg-opacity-10 p-3 rounded-circle text-success mx-auto mb-3" style="width: fit-content;">
                            <i class="bi bi-mortarboard h3 mb-0"></i>
                        </div>
                        <div class="fw-bold mb-1 text-white">Espace Étudiant</div>
                        <div class="xsmall text-muted">Suivi & Historique</div>
                    </a>
                </div>

                <div class="col-md-6">
                    <a href="<?php echo e(route('admin.super.dashboard')); ?>" class="btn list-group-item list-group-item-action p-4 border border-white border-opacity-10 rounded-3 text-center hover-lift h-100">
                        <div class="bg-danger bg-opacity-10 p-3 rounded-circle text-danger mx-auto mb-3" style="width: fit-content;">
                            <i class="bi bi-shield-lock h3 mb-0"></i>
                        </div>
                        <div class="fw-bold mb-1 text-white">Espace Gestion</div>
                        <div class="xsmall text-muted">Administration & Sécurité</div>
                    </a>
                </div>
            </div>

            <style>
                .hover-lift { transition: transform 0.2s ease, box-shadow 0.2s ease; background: rgba(255,255,255,0.02) !important; color: white !important; }
                .hover-lift:hover { transform: translateY(-3px); box-shadow: 0 10px 20px rgba(0,0,0,0.2); background: rgba(255,255,255,0.05) !important; }
                .xsmall { font-size: 0.75rem; }
            </style>

            <div class="mt-5 pt-3 border-top text-center">
                <p class="text-muted small">© 2026 DiplômeTrack — Université de l'Avenir. Tous droits réservés.</p>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\pc\Desktop\S.Diplome Front\diplome-track-demo\resources\views/welcome.blade.php ENDPATH**/ ?>