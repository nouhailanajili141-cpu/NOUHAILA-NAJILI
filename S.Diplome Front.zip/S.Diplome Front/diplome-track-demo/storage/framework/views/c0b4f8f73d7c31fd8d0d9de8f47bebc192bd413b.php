<div class="dt-nav-header">Gestion Académique</div>
<a class="nav-link <?php echo e(($active ?? '') === 'dashboard' ? 'active' : ''); ?>" href="<?php echo e(route('admin.super.dashboard')); ?>">
    <i class="bi bi-speedometer2"></i> Vue d'ensemble
</a>
<a class="nav-link <?php echo e(($active ?? '') === 'students' ? 'active' : ''); ?>" href="<?php echo e(route('admin.students.index')); ?>">
    <i class="bi bi-people"></i> Étudiants
</a>
<a class="nav-link <?php echo e(($active ?? '') === 'diplomas' ? 'active' : ''); ?>" href="<?php echo e(route('admin.diplomas.index')); ?>">
    <i class="bi bi-award"></i> Diplômes
</a>
<a class="nav-link <?php echo e(($active ?? '') === 'validation' ? 'active' : ''); ?>" href="<?php echo e(route('admin.students.validation')); ?>">
    <i class="bi bi-patch-check"></i> Validation
</a>
<a class="nav-link <?php echo e(($active ?? '') === 'status' ? 'active' : ''); ?>" href="<?php echo e(route('admin.diplomas.status')); ?>">
    <i class="bi bi-activity"></i> Suivi Statut
</a>

<div class="dt-nav-header">Sécurité & Système</div>
<a class="nav-link <?php echo e(($active ?? '') === 'users' ? 'active' : ''); ?>" href="<?php echo e(route('admin.users.index')); ?>">
    <i class="bi bi-shield-lock"></i> Comptes Agents
</a>
<a class="nav-link <?php echo e(($active ?? '') === 'roles' ? 'active' : ''); ?>" href="<?php echo e(route('admin.roles.index')); ?>">
    <i class="bi bi-key"></i> Rôles & Accès
</a>
<a class="nav-link <?php echo e(($active ?? '') === 'settings' ? 'active' : ''); ?>" href="<?php echo e(route('app.settings')); ?>">
    <i class="bi bi-gear"></i> Paramètres
</a>

<a class="nav-link text-danger mt-4" href="<?php echo e(route('login')); ?>">
    <i class="bi bi-box-arrow-right"></i> Déconnexion
</a>
<?php /**PATH C:\Users\pc\Desktop\S.Diplome Front\diplome-track-demo\resources\views/partials/sidebar-superadmin.blade.php ENDPATH**/ ?>