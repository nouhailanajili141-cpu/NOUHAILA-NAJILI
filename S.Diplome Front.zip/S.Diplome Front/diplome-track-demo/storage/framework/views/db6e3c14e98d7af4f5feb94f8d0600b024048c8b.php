<?php $__env->startSection('title', 'Historique du Diplôme'); ?>

<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('partials.sidebar-student', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
    <div class="mb-4">
        <h2 class="h3 mb-0 text-gray-800 fw-bold">Historique du Diplôme</h2>
        <p class="text-muted">Retrouvez les détails et l'historique complet de votre parcours.</p>
    </div>

    <div class="row">
        <!-- Informations Finales -->
        <div class="col-lg-4">
            <div class="card border-0 shadow-sm rounded-4 mb-4">
                <div class="card-header bg-transparent border-bottom-0 py-3">
                    <h6 class="fw-bold mb-0">Informations au Retrait</h6>
                </div>
                <div class="card-body">
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item px-0 d-flex justify-content-between align-items-center">
                            <span class="text-muted"><i class="bi bi-calendar-check me-2"></i>Date de retrait</span>
                            <span class="fw-bold">—</span>
                        </li>
                        <li class="list-group-item px-0 d-flex justify-content-between align-items-center">
                            <span class="text-muted"><i class="bi bi-star me-2"></i>Mention obtenue</span>
                            <span class="badge bg-primary rounded-pill px-3 py-2">Très Bien</span>
                        </li>
                        <li class="list-group-item px-0 d-flex justify-content-between align-items-center">
                            <span class="text-muted"><i class="bi bi-person-check me-2"></i>Délivré par</span>
                            <span class="fw-bold text-end">Service Scolarité</span>
                        </li>
                    </ul>
                </div>
            </div>
        </div>

        <!-- Ligne du temps (Timeline) -->
        <div class="col-lg-8">
            <div class="card border-0 shadow-sm rounded-4">
                <div class="card-header bg-transparent border-bottom-0 py-3">
                    <h6 class="fw-bold mb-0">Historique des statuts</h6>
                </div>
                <div class="card-body p-4">
                    <div class="timeline position-relative ps-4" style="border-left: 2px solid #e9ecef;">
                        
                        <!-- Timeline Item 1 -->
                        <div class="timeline-item mb-4 position-relative">
                            <div class="position-absolute bg-success rounded-circle shadow-sm" style="width: 16px; height: 16px; left: -26px; top: 2px;"></div>
                            <div class="card bg-light border-0">
                                <div class="card-body p-3">
                                    <div class="d-flex justify-content-between align-items-center mb-2">
                                        <h6 class="fw-bold text-success mb-0">Résultats Validés</h6>
                                        <span class="text-muted small">24 Juin 2026 à 10:30</span>
                                    </div>
                                    <p class="mb-0 small text-muted">Vos résultats académiques ont été vérifiés. Vous êtes éligible à l'obtention du diplôme.</p>
                                </div>
                            </div>
                        </div>

                        <!-- Timeline Item 2 -->
                        <div class="timeline-item mb-4 position-relative">
                            <div class="position-absolute bg-warning rounded-circle shadow-sm" style="width: 16px; height: 16px; left: -26px; top: 2px;"></div>
                            <div class="card bg-light border-0">
                                <div class="card-body p-3">
                                    <div class="d-flex justify-content-between align-items-center mb-2">
                                        <h6 class="fw-bold text-warning mb-0">En cours de traitement</h6>
                                        <span class="text-muted small">18 Mai 2026 à 14:15</span>
                                    </div>
                                    <p class="mb-0 small text-muted">Dossier en cours d'examen par l'administration.</p>
                                </div>
                            </div>
                        </div>

                        <!-- Timeline Item 3 -->
                        <div class="timeline-item position-relative">
                            <div class="position-absolute bg-secondary rounded-circle shadow-sm" style="width: 16px; height: 16px; left: -26px; top: 2px;"></div>
                            <div class="card bg-light border-0">
                                <div class="timeline-content p-3 rounded-3 bg-white bg-opacity-5 border border-white border-opacity-10">
                                <div class="d-flex justify-content-between mb-1">
                                    <h6 class="fw-bold mb-0 text-white">Demande de Diplôme déposée</h6>
                                    <span class="small text-muted">15/02/2026</span>
                                </div>
                                <p class="small text-muted mb-0">Votre demande a été reçue par le service de la scolarité et est en cours de traitement.</p>
                            </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\pc\Desktop\S.Diplome Front\diplome-track-demo\resources\views/student/history.blade.php ENDPATH**/ ?>