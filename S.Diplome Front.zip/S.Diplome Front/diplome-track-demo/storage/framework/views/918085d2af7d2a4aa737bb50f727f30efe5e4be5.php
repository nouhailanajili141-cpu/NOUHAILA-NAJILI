<?php $__env->startSection('title', 'Gestion des Comptes'); ?>

<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('partials.sidebar-superadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="h3 mb-0 text-white fw-bold">Gestion des Utilisateurs</h2>
            <p class="text-muted">Gérez les accès au système et les comptes de tous les utilisateurs.</p>
        </div>
        <button class="btn btn-primary d-flex align-items-center gap-2 rounded-3 shadow-sm" data-bs-toggle="modal" data-bs-target="#addUserModal">
            <i class="bi bi-person-plus-fill"></i> Nouvel Utilisateur
        </button>
    </div>

    <!-- Table -->
    <div class="card border-0 mb-4">
        <div class="card-header d-flex justify-content-between">
            <div class="input-group" style="width: 300px;">
                <span class="input-group-text"><i class="bi bi-search"></i></span>
                <input type="text" class="form-control" placeholder="Rechercher...">
            </div>
            <select class="form-select" style="width: 200px;">
                <option selected class="bg-dark text-white">Tous les Rôles</option>
                <option class="bg-dark text-white">Administrateur Système</option>
                <option class="bg-dark text-white">Scolarité (Administration)</option>
                <option class="bg-dark text-white">Étudiant</option>
            </select>
        </div>
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="bg-white bg-opacity-5">
                    <tr>
                        <th class="ps-4">Utilisateur</th>
                        <th>Email / Identifiant</th>
                        <th>Rôle</th>
                        <th>Dernière connexion</th>
                        <th class="text-end pe-4">Actions</th>
                    </tr>
                </thead>
                <tbody class="border-top-0">
                    <tr>
                        <td class="ps-4">
                            <div class="d-flex align-items-center">
                                <div class="bg-primary bg-opacity-10 text-primary rounded-circle d-flex justify-content-center align-items-center fw-bold me-3 text-white-force" style="width: 40px; height: 40px; background: rgba(var(--primary-rgb), 0.2) !important;">
                                    AD
                                </div>
                                <div class="fw-bold text-white">Super Admin</div>
                            </div>
                        </td>
                        <td class="text-white-force">admin@univ.ma</td>
                        <td><span class="badge status-delivre rounded-pill px-3">Administrateur</span></td>
                        <td class="text-muted small">01/05/2026 14:00</td>
                        <td class="text-end pe-4">
                            <button class="btn btn-sm btn-glass rounded-circle text-white"><i class="bi bi-shield-lock"></i></button>
                            <button class="btn btn-sm btn-glass rounded-circle text-primary"><i class="bi bi-pencil"></i></button>
                        </td>
                    </tr>
                    <tr>
                        <td class="ps-4">
                            <div class="d-flex align-items-center">
                                <div class="bg-warning bg-opacity-10 text-warning rounded-circle d-flex justify-content-center align-items-center fw-bold me-3 text-white-force" style="width: 40px; height: 40px;">
                                    SM
                                </div>
                                <div class="fw-bold text-white">Service Scolarité</div>
                            </div>
                        </td>
                        <td class="text-white-force">scolarite@univ.ma</td>
                        <td><span class="badge status-valide rounded-pill px-3">Administration</span></td>
                        <td class="text-muted small">Aujourd'hui, 09:30</td>
                        <td class="text-end pe-4">
                            <button class="btn btn-sm btn-glass rounded-circle text-white"><i class="bi bi-shield-lock"></i></button>
                            <button class="btn btn-sm btn-glass rounded-circle text-primary"><i class="bi bi-pencil"></i></button>
                            <button class="btn btn-sm btn-glass rounded-circle text-danger"><i class="bi bi-trash"></i></button>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('modals'); ?>
<!-- Modal Création Utilisateur -->
<div class="modal fade" id="addUserModal" tabindex="-1" style="z-index: 9999;">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content rounded-4 border-0 shadow-lg bg-dark text-light border border-white border-opacity-10">
            <div class="modal-header border-bottom border-white border-opacity-10 pb-3">
                <h5 class="modal-title fw-bold">Créer un Compte Système</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4">
                <form>
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Nom Complet</label>
                        <input type="text" class="form-control bg-white bg-opacity-5 border-white border-opacity-10" placeholder="Ex: Admin Scolarité" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Email ou Identifiant de connexion</label>
                        <input type="text" class="form-control bg-white bg-opacity-5 border-white border-opacity-10" placeholder="Ex: agent@univ.ma" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Mot de passe provisoire</label>
                        <input type="password" class="form-control bg-white bg-opacity-5 border-white border-opacity-10" required>
                    </div>
                    <div class="mb-1">
                        <label class="form-label small fw-bold">Rôle d'accès & Permissions</label>
                        <select class="form-select bg-primary bg-opacity-10 text-primary border-primary border-opacity-25 fw-bold" required>
                            <option value="" class="bg-dark text-light">Sélectionner un rôle</option>
                            <option value="admin" class="bg-dark text-light">Administrateur Système</option>
                            <option value="management" class="bg-dark text-light">Administration (Scolarité)</option>
                            <option value="student" class="bg-dark text-light">Étudiant</option>
                        </select>
                    </div>
                </form>
            </div>
            <div class="modal-footer border-top border-white border-opacity-10 pt-3 d-flex justify-content-between">
                <button type="button" class="btn btn-glass px-4" data-bs-dismiss="modal">Annuler</button>
                <button type="button" class="btn btn-primary px-4 shadow-lg">Créer l'utilisateur</button>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\pc\Desktop\S.Diplome Front\diplome-track-demo\resources\views/admin/users/index.blade.php ENDPATH**/ ?>