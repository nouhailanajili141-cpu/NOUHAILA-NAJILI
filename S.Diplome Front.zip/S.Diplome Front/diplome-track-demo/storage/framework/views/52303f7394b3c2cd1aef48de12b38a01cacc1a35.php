

<?php $__env->startSection('title', 'Connexion | DiplômeTrack'); ?>

<?php $__env->startSection('content'); ?>
<div class="card auth-card shadow-lg border-0 overflow-hidden" style="max-width: 450px;">
    <div class="p-4 p-lg-5">
        <div class="text-center mb-5">
            <div class="bg-primary bg-opacity-10 p-3 rounded-circle d-inline-flex mb-3">
                <i class="bi bi-mortarboard-fill h2 mb-0 text-primary"></i>
            </div>
            <h1 class="h3 fw-bold mb-1">DiplômeTrack</h1>
            <p class="text-muted small">Portail d'Authentification Universitaire</p>
        </div>

        <form method="POST" action="#" id="loginForm">
            <?php echo csrf_field(); ?>
            
            <div class="mb-3">
                <label class="form-label small fw-bold text-muted">Identifiant Apogée</label>
                <div class="position-relative">
                    <i class="bi bi-person position-absolute top-50 start-0 translate-middle-y ms-3 text-muted"></i>
                    <input type="text" name="login" class="form-control ps-5" placeholder="Ex: 21004567" required>
                </div>
            </div>

            <div class="mb-4">
                <label class="form-label small fw-bold text-muted">Mot de passe (CNE)</label>
                <div class="position-relative">
                    <i class="bi bi-shield-lock position-absolute top-50 start-0 translate-middle-y ms-3 text-muted"></i>
                    <input type="password" name="password" class="form-control ps-5" placeholder="••••••••" required>
                </div>
            </div>

            <div class="d-flex justify-content-between align-items-center mb-4">
                <div class="form-check small">
                    <input class="form-check-input" type="checkbox" id="remember">
                    <label class="form-check-label text-muted" for="remember">Rester connecté</label>
                </div>
                <a href="#" class="small text-primary text-decoration-none fw-bold">Oubli ?</a>
            </div>

            <button type="submit" class="btn btn-primary w-100 py-3 shadow-lg mb-4">
                Se connecter
            </button>

            <div class="text-center">
                <p class="text-muted small mb-4">Accès rapide pour test :</p>
                <div class="d-flex gap-2">
                    <a href="<?php echo e(route('student.dashboard')); ?>" class="btn btn-glass btn-sm flex-grow-1 xsmall">Étudiant</a>
                    <a href="<?php echo e(route('admin.super.dashboard')); ?>" class="btn btn-glass btn-sm flex-grow-1 xsmall">Admin Admin</a>
                </div>
            </div>
        </form>
    </div>
</div>

<script>
    document.getElementById('loginForm').addEventListener('submit', function(e) {
        e.preventDefault();
        window.location.href = "<?php echo e(route('app.home')); ?>";
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\pc\Desktop\S.Diplome Front\diplome-track-demo\resources\views/auth/login.blade.php ENDPATH**/ ?>