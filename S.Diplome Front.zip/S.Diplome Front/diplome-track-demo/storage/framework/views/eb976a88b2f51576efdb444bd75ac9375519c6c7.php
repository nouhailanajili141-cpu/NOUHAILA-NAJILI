<div class="p-3">
    <div class="d-flex align-items-center gap-3 mb-4 ps-2">
        <div class="bg-primary bg-opacity-10 p-2 rounded-3 text-primary">
            <i class="bi bi-gem h4 mb-0"></i>
        </div>
        <div class="fw-bold text-light" style="letter-spacing: 0.5px;">DiplômeTrack</div>
    </div>

    <div class="small text-muted mb-3 ps-2 text-uppercase" style="font-size: 0.65rem; letter-spacing: 1px;">Navigation</div>
    <nav class="nav flex-column gap-2 mb-4">
        <a class="nav-link py-2 px-3 rounded-2 <?php echo e(($active ?? '') === 'home' ? 'active shadow-sm' : ''); ?>" href="<?php echo e(route('app.home')); ?>">
            <i class="bi bi-grid-fill me-3"></i>Accueil
        </a>
        <a class="nav-link py-2 px-3 rounded-2 <?php echo e(($active ?? '') === 'settings' ? 'active shadow-sm' : ''); ?>" href="<?php echo e(route('app.settings')); ?>">
            <i class="bi bi-gear-fill me-3"></i>Paramètres
        </a>
        <a class="nav-link py-2 px-3 rounded-2 <?php echo e(($active ?? '') === 'support' ? 'active shadow-sm' : ''); ?>" href="<?php echo e(route('app.support')); ?>">
            <i class="bi bi-headset me-3"></i>Support
        </a>
    </nav>

    <div class="small text-muted mb-3 ps-2 text-uppercase" style="font-size: 0.65rem; letter-spacing: 1px;">Administration</div>
    <nav class="nav flex-column gap-2 mb-4">
        <a class="nav-link py-2 px-3 rounded-2 <?php echo e(($active ?? '') === 'admin.students' ? 'active shadow-sm' : ''); ?>" href="<?php echo e(route('admin.students.index')); ?>">
            <i class="bi bi-people-fill me-3"></i>Gestion Étudiants
        </a>
        <a class="nav-link py-2 px-3 rounded-2 <?php echo e(($active ?? '') === 'admin.diplomas' ? 'active shadow-sm' : ''); ?>" href="<?php echo e(route('admin.diplomas.index')); ?>">
            <i class="bi bi-award-fill me-3"></i>Gestion Diplômes
        </a>
        <a class="nav-link py-2 px-3 rounded-2 <?php echo e(($active ?? '') === 'admin.validation' ? 'active shadow-sm' : ''); ?>" href="<?php echo e(route('admin.students.validation')); ?>">
            <i class="bi bi-check-circle-fill me-3"></i>Validation Résultats
        </a>
    </nav>

    <div class="small text-muted mb-3 ps-2 text-uppercase" style="font-size: 0.65rem; letter-spacing: 1px;">Système</div>
    <nav class="nav flex-column gap-2">
        <a class="nav-link py-2 px-3 rounded-2 <?php echo e(($active ?? '') === 'admin.users' ? 'active shadow-sm' : ''); ?>" href="<?php echo e(route('admin.users.index')); ?>">
            <i class="bi bi-shield-lock-fill me-3"></i>Comptes Utilisateurs
        </a>
        <div class="border-top border-white border-opacity-10 my-2"></div>
        <a class="nav-link py-2 px-3 rounded-2 text-danger font-bold" href="<?php echo e(route('login')); ?>">
            <i class="bi bi-box-arrow-right me-3"></i>Déconnexion
        </a>
    </nav>
</div>

<?php /**PATH C:\Users\pc\Desktop\S.Diplome Front\diplome-track-demo\resources\views/partials/sidebar-generic.blade.php ENDPATH**/ ?>