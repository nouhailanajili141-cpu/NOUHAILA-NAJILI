

<?php $__env->startSection('title', 'Paramètres | DiplômeTrack'); ?>
<?php $__env->startSection('page_title', 'Configuration du Compte'); ?>

<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('partials.sidebar-generic', ['active' => 'settings'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row g-4">
    <div class="col-lg-7">
        <div class="card h-100">
            <div class="card-header"><i class="bi bi-sliders me-2 text-primary"></i>Préférences de l'Interface</div>
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label small text-muted">Langue du Système</label>
                        <select class="form-select">
                            <option selected>Français (FR)</option>
                            <option>العربية (AR)</option>
                            <option>English (EN)</option>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small text-muted">Canal de Notifications</label>
                        <select class="form-select">
                            <option selected>Email & Push</option>
                            <option>Email uniquement</option>
                            <option>Désactivé</option>
                        </select>
                    </div>
                </div>

                <hr class="my-4 border-white border-opacity-10">

                <h6 class="fw-bold mb-3">Apparence</h6>
                <div class="d-flex align-items-center justify-content-between p-3 bg-light bg-opacity-10 rounded-3 mb-4">
                    <div>
                        <div class="fw-bold small">Thème Premium (Auto)</div>
                        <div class="xsmall text-muted">L'interface s'adapte automatiquement à votre système.</div>
                    </div>
                    <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" checked disabled>
                    </div>
                </div>

                <div class="d-flex gap-2">
                    <button class="btn btn-primary px-4">Sauvegarder</button>
                    <button class="btn btn-glass px-4">Réinitialiser</button>
                </div>
            </div>
        </div>
    </div>

    <div class="col-lg-5">
        <div class="card h-100">
            <div class="card-header"><i class="bi bi-person-badge me-2 text-primary"></i>Identité & Session</div>
            <div class="card-body text-center py-4">
                <div class="position-relative d-inline-block mb-3">
                    <div class="bg-primary bg-opacity-20 rounded-circle d-flex align-items-center justify-content-center" style="width: 80px; height: 80px;">
                        <i class="bi bi-person text-primary h1 mb-0"></i>
                    </div>
                    <button class="btn btn-primary btn-sm rounded-circle position-absolute bottom-0 end-0 p-1" style="width: 25px; height: 25px;">
                        <i class="bi bi-pencil xsmall"></i>
                    </button>
                </div>
                <h5 class="fw-bold mb-1">Utilisateur Démo</h5>
                <p class="text-muted small mb-4">demo.user@univ.ma</p>

                <div class="list-group list-group-flush text-start mb-4 border-top border-white border-opacity-10">
                    <div class="list-group-item bg-transparent px-0 py-3 d-flex justify-content-between align-items-center border-white border-opacity-10">
                        <span class="small text-muted"><i class="bi bi-shield-check me-2"></i>Rôle Actif</span>
                        <span class="badge bg-soft text-primary">Utilisateur Démo</span>
                    </div>
                    <div class="list-group-item bg-transparent px-0 py-3 d-flex justify-content-between align-items-center border-white border-opacity-10">
                        <span class="small text-muted"><i class="bi bi-key me-2"></i>Dernière Connexion</span>
                        <span class="small">Aujourd'hui, 10:45</span>
                    </div>
                </div>

                <div class="d-grid gap-2">
                    <button class="btn btn-outline-danger btn-sm"><i class="bi bi-box-arrow-right me-2"></i>Déconnexion de la Session</button>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\pc\Desktop\S.Diplome Front\diplome-track-demo\resources\views/pages/settings.blade.php ENDPATH**/ ?>