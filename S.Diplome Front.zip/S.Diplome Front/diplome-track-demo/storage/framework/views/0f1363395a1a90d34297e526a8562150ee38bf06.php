

<?php $__env->startSection('title', 'Support & Aide | DiplômeTrack'); ?>
<?php $__env->startSection('page_title', 'Assistance Technique'); ?>

<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('partials.sidebar-generic', ['active' => 'support'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row g-4">
    <div class="col-lg-7">
        <div class="card h-100">
            <div class="card-header"><i class="bi bi-question-diamond me-2 text-primary"></i>Questions Fréquentes (FAQ)</div>
            <div class="card-body p-0">
                <div class="accordion accordion-flush" id="supportFaq">
                    <div class="accordion-item bg-transparent">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed bg-transparent text-light fw-bold" type="button" data-bs-toggle="collapse" data-bs-target="#f1">
                                Comment suivre l’état de mon diplôme ?
                            </button>
                        </h2>
                        <div id="f1" class="accordion-collapse collapse" data-bs-parent="#supportFaq">
                            <div class="accordion-body small text-muted">
                                Rendez-vous sur votre tableau de bord étudiant. Le statut est mis à jour en temps réel par les services administratifs (En cours, Validé, Prêt pour remise).
                            </div>
                        </div>
                    </div>
                    <div class="accordion-item bg-transparent">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed bg-transparent text-light fw-bold" type="button" data-bs-toggle="collapse" data-bs-target="#f2">
                                Que signifie le statut "Annulé" ?
                            </button>
                        </h2>
                        <div id="f2" class="accordion-collapse collapse" data-bs-parent="#supportFaq">
                            <div class="accordion-body small text-muted">
                                Un diplôme est annulé en cas d'erreur dans les résultats académiques ou si le dossier est jugé incomplet lors de la phase de validation.
                            </div>
                        </div>
                    </div>
                    <div class="accordion-item bg-transparent">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed bg-transparent text-light fw-bold" type="button" data-bs-toggle="collapse" data-bs-target="#f3">
                                Comment modifier mes informations personnelles ?
                            </button>
                        </h2>
                        <div id="f3" class="accordion-collapse collapse" data-bs-parent="#supportFaq">
                            <div class="accordion-body small text-muted">
                                Les modifications d'identité doivent être signalées au service de scolarité muni de vos pièces justificatives originales.
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-lg-5">
        <div class="card h-100 border-0 shadow-sm glass-card">
            <div class="card-header bg-transparent border-white border-opacity-10">
                <span class="fw-bold"><i class="bi bi-envelope-at me-2 text-primary"></i>Besoin d'aide ?</span>
            </div>
            <div class="card-body">
                <form action="#" id="supportForm">
                    <div class="mb-3">
                        <label class="form-label small text-muted">Sujet de la demande</label>
                        <select class="form-select">
                            <option>Problème de connexion</option>
                            <option>Erreur dans les données</option>
                            <option>Question sur le retrait</option>
                            <option>Autre...</option>
                        </select>
                    </div>
                    <div class="mb-4">
                        <label class="form-label small text-muted">Description détaillée</label>
                        <textarea class="form-control" rows="5" placeholder="Décrivez votre problème ici..."></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="bi bi-send-fill me-2"></i>Envoyer le Ticket
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
    document.getElementById('supportForm').addEventListener('submit', function(e) {
        e.preventDefault();
        alert('Action UI: Votre ticket a été envoyé au support technique.');
    });
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\pc\Desktop\S.Diplome Front\diplome-track-demo\resources\views/pages/support.blade.php ENDPATH**/ ?>