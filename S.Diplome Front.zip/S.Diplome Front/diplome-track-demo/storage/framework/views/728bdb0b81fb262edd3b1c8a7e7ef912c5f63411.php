<div class="dt-nav-header">Espace Étudiant</div>
<a class="nav-link <?php echo e(($active ?? '') === 'dashboard' ? 'active' : ''); ?>" href="<?php echo e(route('student.dashboard')); ?>">
    <i class="bi bi-grid-1x2"></i> Tableau de bord
</a>
<a class="nav-link <?php echo e(($active ?? '') === 'history' ? 'active' : ''); ?>" href="<?php echo e(route('student.history')); ?>">
    <i class="bi bi-clock-history"></i> Historique
</a>

<div class="dt-nav-header">Paramètres</div>
<a class="nav-link" href="<?php echo e(route('app.settings')); ?>">
    <i class="bi bi-person-gear"></i> Mon Profil
</a>
<a class="nav-link" href="<?php echo e(route('app.support')); ?>">
    <i class="bi bi-question-circle"></i> Support
</a>
<a class="nav-link text-danger mt-4" href="<?php echo e(route('login')); ?>">
    <i class="bi bi-box-arrow-right"></i> Déconnexion
</a>
<?php /**PATH C:\Users\pc\Desktop\S.Diplome Front\diplome-track-demo\resources\views/partials/sidebar-student.blade.php ENDPATH**/ ?>