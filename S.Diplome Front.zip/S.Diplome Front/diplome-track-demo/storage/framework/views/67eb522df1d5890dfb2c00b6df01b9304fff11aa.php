<div class="dt-nav-header">Administration</div>
<a class="nav-link <?php echo e(($active ?? '') === 'students' ? 'active' : ''); ?>" href="<?php echo e(route('admin.students.index')); ?>">
    <i class="bi bi-people"></i> Étudiants
</a>
<a class="nav-link <?php echo e(($active ?? '') === 'diplomas' ? 'active' : ''); ?>" href="<?php echo e(route('admin.diplomas.index')); ?>">
    <i class="bi bi-award"></i> Diplômes
</a>
<a class="nav-link <?php echo e(($active ?? '') === 'validation' ? 'active' : ''); ?>" href="<?php echo e(route('admin.students.validation')); ?>">
    <i class="bi bi-patch-check"></i> Validation Résultats
</a>
<a class="nav-link <?php echo e(($active ?? '') === 'status' ? 'active' : ''); ?>" href="<?php echo e(route('admin.diplomas.status')); ?>">
    <i class="bi bi-arrow-repeat"></i> Suivi Diplômes
</a>

<div class="dt-nav-header">Compte</div>
<a class="nav-link" href="<?php echo e(route('app.settings')); ?>">
    <i class="bi bi-person-badge"></i> Mon Profil
</a>
<a class="nav-link text-danger mt-4" href="<?php echo e(route('login')); ?>">
    <i class="bi bi-box-arrow-right"></i> Déconnexion
</a>
<?php /**PATH C:\Users\pc\Desktop\S.Diplome Front\diplome-track-demo\resources\views/partials/sidebar-admin.blade.php ENDPATH**/ ?>