<?php $__env->startSection('title', ($title ?? 'Détails') . ' | DiplômeTrack'); ?>
<?php $__env->startSection('page_title', $title ?? 'Détails'); ?>

<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('partials.sidebar-generic', ['active' => ''], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row g-3">
    <div class="col-12 col-lg-8">
        <div class="card dt-card shadow-sm">
            <div class="card-body">
                <div class="d-flex flex-wrap align-items-center justify-content-between gap-2 mb-2">
                    <div>
                        <div class="fw-bold"><?php echo e($title ?? 'Détails'); ?></div>
                        <div class="dt-muted small">Écran “placeholder” (UI) — à remplacer/brancher au backend.</div>
                    </div>
                    <a class="btn btn-soft btn-sm" href="<?php echo e(url()->previous()); ?>"><i class="bi bi-arrow-left me-1"></i>Retour</a>
                </div>

                <hr style="border-color: var(--dt-border);">

                <div class="dt-muted">
                    <div class="mb-2"><span class="badge badge-soft">Clé</span> <span class="ms-2 text-light fw-semibold"><?php echo e($key ?? '—'); ?></span></div>
                    <div class="mb-2"><span class="badge badge-soft">ID (démo)</span> <span class="ms-2 text-light fw-semibold"><?php echo e($id ?? '—'); ?></span></div>
                    <div class="mb-0">Ici tu peux afficher les champs du MCD (lecture seule) ou un formulaire détaillé.</div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-12 col-lg-4">
        <div class="card dt-card shadow-sm">
            <div class="card-body">
                <div class="fw-bold mb-2">Actions</div>
                <div class="d-grid gap-2">
                    <button class="btn btn-primary"><i class="bi bi-pencil me-2"></i>Modifier (UI)</button>
                    <button class="btn btn-soft"><i class="bi bi-download me-2"></i>Exporter (UI)</button>
                    <a class="btn btn-soft" href="<?php echo e(route('app.support')); ?>"><i class="bi bi-question-circle me-2"></i>Support</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\pc\Desktop\S.Diplome Front\diplome-track-demo\resources\views/pages/placeholder.blade.php ENDPATH**/ ?>