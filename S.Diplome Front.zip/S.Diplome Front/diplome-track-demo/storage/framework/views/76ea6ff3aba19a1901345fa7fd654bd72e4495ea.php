<?php $__env->startSection('title', 'Tableau de Bord Administrateur'); ?>

<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('partials.sidebar-superadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
    <div class="mb-4">
        <h2 class="h3 mb-0 text-white fw-bold">Espace Administrateur Système</h2>
        <p class="text-muted">Vue globale sur la gestion des comptes et la sécurité du système.</p>
    </div>

    <!-- KPI -->
    <div class="row g-4 mb-4">
        <div class="col-md-3">
            <div class="card border-0 shadow-sm rounded-4 h-100">
                <div class="card-body p-4 d-flex align-items-center gap-3">
                    <div class="bg-primary bg-opacity-10 text-primary rounded-circle p-3">
                        <i class="bi bi-people-fill h4 mb-0"></i>
                    </div>
                    <div>
                        <h6 class="text-muted fw-bold mb-1 small text-uppercase">Comptes Totaux</h6>
                        <h3 class="fw-bolder mb-0">1,245</h3>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-0 shadow-sm rounded-4 h-100">
                <div class="card-body p-4 d-flex align-items-center gap-3">
                    <div class="bg-danger bg-opacity-10 text-danger rounded-circle p-3">
                        <i class="bi bi-shield-lock-fill h4 mb-0"></i>
                    </div>
                    <div>
                        <h6 class="text-muted fw-bold mb-1 small text-uppercase">Admins. Système</h6>
                        <h3 class="fw-bolder mb-0">3</h3>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-0 shadow-sm rounded-4 h-100">
                <div class="card-body p-4 d-flex align-items-center gap-3">
                    <div class="bg-warning bg-opacity-10 text-warning rounded-circle p-3">
                        <i class="bi bi-briefcase-fill h4 mb-0"></i>
                    </div>
                    <div>
                        <h6 class="text-muted fw-bold mb-1 small text-uppercase">Agents Scolarité</h6>
                        <h3 class="fw-bolder mb-0">12</h3>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-0 shadow-sm rounded-4 h-100">
                <div class="card-body p-4 d-flex align-items-center gap-3">
                    <div class="bg-success bg-opacity-10 text-success rounded-circle p-3">
                        <i class="bi bi-mortarboard-fill h4 mb-0"></i>
                    </div>
                    <div>
                        <h6 class="text-muted fw-bold mb-1 small text-uppercase">Étudiants Actifs</h6>
                        <h3 class="fw-bolder mb-0">1,230</h3>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Content -->
    <div class="card border-0 shadow-sm rounded-4">
        <div class="card-header bg-transparent border-bottom border-white border-opacity-10 px-4 py-3">
            <h5 class="fw-bold mb-0 text-white">Activité Récente Système</h5>
        </div>
        <div class="card-body p-0">
            <table class="table table-hover align-middle mb-0 border-0">
                <tbody class="border-top-0">
                    <tr>
                        <td class="ps-4">
                            <span class="badge bg-primary bg-opacity-10 text-primary border border-primary border-opacity-25 py-1 px-2 rounded-2">Connexion</span>
                        </td>
                        <td>Admin Scolarité (admin@univ.ma)</td>
                        <td class="text-muted text-end pe-4 small">Il y a 5 min</td>
                    </tr>
                    <tr>
                        <td class="ps-4">
                            <span class="badge bg-success bg-opacity-10 text-success border border-success border-opacity-25 py-1 px-2 rounded-2">Modification</span>
                        </td>
                        <td>SuperAdmin (root@univ.ma) a modifié le rôle de 'h.kamal'.</td>
                        <td class="text-muted text-end pe-4 small">Il y a 2 heures</td>
                    </tr>
                    <tr>
                        <td class="ps-4">
                            <span class="badge bg-danger bg-opacity-10 text-danger border border-danger border-opacity-25 py-1 px-2 rounded-2">Création</span>
                        </td>
                        <td>Nouveau compte étudiant créé (19012345).</td>
                        <td class="text-muted text-end pe-4 small">Hier à 10:20</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\pc\Desktop\S.Diplome Front\diplome-track-demo\resources\views/admin/super-dashboard.blade.php ENDPATH**/ ?>