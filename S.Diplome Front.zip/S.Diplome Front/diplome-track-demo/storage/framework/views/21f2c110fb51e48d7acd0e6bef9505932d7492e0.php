<?php $__env->startSection('title', 'Suivi du Diplôme'); ?>

<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('partials.sidebar-generic', ['active' => 'admin.diplomas'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="h3 mb-0 text-gray-800 fw-bold">Mise à jour du statut : Aymane Jabri</h2>
            <p class="text-muted">Licence Fondamentale - Génie Logiciel</p>
        </div>
        <a href="<?php echo e(route('admin.diplomas.index')); ?>" class="btn btn-light border shadow-sm">
            <i class="bi bi-arrow-left me-2"></i>Retour
        </a>
    </div>

    <div class="row">
        <!-- Formulaire de MAJ de l'état -->
        <div class="col-lg-5 mb-4">
            <div class="card border-0 shadow-sm rounded-4 h-100">
                <div class="card-header bg-transparent py-3 border-bottom-0">
                    <h5 class="fw-bold mb-0">Modifier l'état du diplôme</h5>
                </div>
                <div class="card-body">
                    <form>
                        <div class="mb-4">
                            <label class="form-label fw-semibold">Nouveau Statut</label>
                            <select class="form-select border-primary" style="background-color: #f8fbff;">
                                <option value="en_cours">En cours</option>
                                <option value="valide" selected>Validé</option>
                                <option value="delivre">Délivré</option>
                                <option value="annule">Annulé</option>
                            </select>
                        </div>

                        <!-- Si délivré -->
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Date de remise (si applicable)</label>
                            <input type="date" class="form-control">
                        </div>

                        <div class="mb-4">
                            <label class="form-label fw-semibold">Mention obtenue</label>
                            <select class="form-select">
                                <option>-- Sélectionner --</option>
                                <option>Passable</option>
                                <option>Assez Bien</option>
                                <option>Bien</option>
                                <option selected>Très Bien</option>
                                <option>Excellent</option>
                            </select>
                        </div>

                        <button type="submit" class="btn btn-primary w-100 py-2 rounded-3">Enregistrer la modification</button>
                    </form>
                </div>
            </div>
        </div>

        <!-- Historique de cet étudiant (Vue Admin) -->
        <div class="col-lg-7 mb-4">
            <div class="card border-0 shadow-sm rounded-4 h-100">
                <div class="card-header bg-transparent py-3 border-bottom-0">
                    <h5 class="fw-bold mb-0">Historique des actions</h5>
                </div>
                <div class="card-body p-4">
                    <div class="timeline position-relative ps-4" style="border-left: 2px solid #e9ecef;">
                        <!-- Item -->
                        <div class="timeline-item mb-4 position-relative">
                            <div class="position-absolute bg-success rounded-circle shadow-sm" style="width: 14px; height: 14px; left: -25px; top: 4px;"></div>
                            <div class="d-flex justify-content-between align-items-center mb-1">
                                <h6 class="fw-bold mb-0">Validation des résultats</h6>
                                <span class="text-muted small">24 Juin 2026 à 10:30</span>
                            </div>
                            <p class="mb-1 small">Diplôme passé au statut <strong>Validé</strong>. (Mention Très Bien)</p>
                            <div class="text-muted small fst-italic">Opération par: Admin Scolarité</div>
                        </div>

                        <!-- Item -->
                        <div class="timeline-item position-relative">
                            <div class="position-absolute bg-secondary rounded-circle shadow-sm" style="width: 14px; height: 14px; left: -25px; top: 4px;"></div>
                            <div class="d-flex justify-content-between align-items-center mb-1">
                                <h6 class="fw-bold mb-0">Création du suivi</h6>
                                <span class="text-muted small">15 Mai 2026 à 09:00</span>
                            </div>
                            <p class="mb-1 small">Dossier créé. Statut: <strong>En cours</strong>.</p>
                            <div class="text-muted small fst-italic">Opération par: Système</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\pc\Desktop\S.Diplome Front\diplome-track-demo\resources\views/admin/diplomas/status.blade.php ENDPATH**/ ?>