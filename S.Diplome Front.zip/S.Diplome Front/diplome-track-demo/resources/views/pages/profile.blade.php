@extends('layouts.panel')

@section('title', 'Mon Profil | DiplômeTrack')
@section('page_title', 'Profil Utilisateur')
@section('user_role', 'Utilisateur')

@section('sidebar')
    @php $active = 'profile'; @endphp
    @include('partials.sidebar-generic')
@endsection

@section('content')
<div class="row g-4">
    <div class="col-lg-4">
        <div class="card text-center p-5 h-100">
            <div class="position-relative d-inline-block mx-auto mb-4">
                <div class="bg-primary rounded-circle d-flex align-items-center justify-content-center text-white" style="width: 120px; height: 120px; font-size: 3rem;">
                    <i class="bi bi-person-fill"></i>
                </div>
                <button class="btn btn-primary btn-sm position-absolute bottom-0 end-0 rounded-circle p-2">
                    <i class="bi bi-camera"></i>
                </button>
            </div>
            <h3 class="fw-bold mb-1 text-white">Sara EL AMRANI</h3>
            <p class="text-muted">Étudiante en SMI</p>
            <div class="badge bg-soft-primary text-primary px-3 py-2 mb-4">Compte Actif</div>
            
            <div class="d-grid gap-2">
                <button class="btn btn-primary">Modifier Photo</button>
                <button class="btn btn-glass">Voir Certificats</button>
            </div>
        </div>
    </div>

    <div class="col-lg-8">
        <div class="card h-100">
            <div class="card-header d-flex justify-content-between align-items-center text-white border-bottom border-white border-opacity-10">
                <span>Informations Personnelles</span>
                <button class="btn btn-glass btn-sm"><i class="bi bi-pencil me-1"></i> Éditer</button>
            </div>
            <div class="card-body">
                <div class="row g-4">
                    <div class="col-md-6">
                        <label class="small text-muted mb-1">Nom Complet</label>
                        <div class="fw-bold text-white border-bottom border-white border-opacity-5 pb-2">Sara EL AMRANI</div>
                    </div>
                    <div class="col-md-6">
                        <label class="small text-muted mb-1">Email académique</label>
                        <div class="fw-bold text-white border-bottom border-white border-opacity-5 pb-2">s.elamrani@univ.ma</div>
                    </div>
                    <div class="col-md-6">
                        <label class="small text-muted mb-1">Code Apogée</label>
                        <div class="fw-bold text-white border-bottom border-white border-opacity-5 pb-2">21004567</div>
                    </div>
                    <div class="col-md-6">
                        <label class="small text-muted mb-1">CNE</label>
                        <div class="fw-bold text-white border-bottom border-white border-opacity-5 pb-2">D135678902</div>
                    </div>
                </div>

                <h6 class="fw-bold mt-5 mb-3 text-primary">Paramètres de Sécurité</h6>
                <div class="d-grid gap-3">
                    <div class="p-3 rounded-3 bg-white bg-opacity-5 d-flex justify-content-between align-items-center">
                        <div class="d-flex align-items-center gap-3">
                            <i class="bi bi-shield-lock h4 mb-0 text-success"></i>
                            <div>
                                <div class="fw-bold text-white">Double Authentification (2FA)</div>
                                <div class="xsmall text-muted">Ajouter une couche de sécurité extra</div>
                            </div>
                        </div>
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" role="switch" checked>
                        </div>
                    </div>
                    <div class="p-3 rounded-3 bg-white bg-opacity-5 d-flex justify-content-between align-items-center">
                        <div class="d-flex align-items-center gap-3">
                            <i class="bi bi-key h4 mb-0 text-warning"></i>
                            <div>
                                <div class="fw-bold text-white">Changer le mot de passe</div>
                                <div class="xsmall text-muted">Dernière modification : il y a 3 mois</div>
                            </div>
                        </div>
                        <button class="btn btn-glass btn-sm">Gérer</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
