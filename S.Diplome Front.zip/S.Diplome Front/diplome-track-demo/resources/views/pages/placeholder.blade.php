@extends('layouts.panel')

@section('title', ($title ?? 'Détails') . ' | DiplômeTrack')
@section('page_title', $title ?? 'Détails')

@section('sidebar')
    @include('partials.sidebar-generic')
@endsection

@section('content')
<div class="card text-center p-5">
    <div class="card-body py-5">
        <div class="mb-4">
            <div class="bg-primary bg-opacity-10 rounded-circle d-inline-flex align-items-center justify-content-center" style="width: 100px; height: 100px;">
                <i class="bi bi-tools text-primary h1 mb-0"></i>
            </div>
        </div>
        <h2 class="fw-bold mb-3">{{ $title ?? 'Détails' }}</h2>
        <p class="text-muted mx-auto" style="max-width: 500px;">
            L'écran de détails pour l'entité <strong>{{ $key ?? 'Inconnue' }}</strong> (ID: {{ $id ?? 'N/A' }}) est actuellement en préparation. 
            Il sera connecté au backend pour afficher les données réelles du MCD.
        </p>
        <div class="mt-4">
            <a href="{{ url()->previous() }}" class="btn btn-glass btn-lg px-4 me-2">
                <i class="bi bi-arrow-left me-2"></i>Retour
            </a>
            <a href="{{ route('student.dashboard') }}" class="btn btn-primary btn-lg px-4">
                <i class="bi bi-house me-2"></i>Tableau de Bord
            </a>
        </div>
    </div>
</div>
@endsection

