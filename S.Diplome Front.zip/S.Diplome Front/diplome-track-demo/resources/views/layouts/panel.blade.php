<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>@yield('title', 'Gestion Diplômes | Université')</title>

    <!-- Google Fonts: Inter & Outfit -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Outfit:wght@500;600;700&display=swap" rel="stylesheet">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    
    <style>
        :root {
            --primary: #6366f1;
            --primary-rgb: 99, 102, 241;
            --primary-light: #818cf8;
            --secondary: #0ea5e9;
            --bg-color: #050b18;
            --surface: rgba(17, 25, 40, 0.75);
            --surface-hover: rgba(17, 25, 40, 0.9);
            --border-color: rgba(255, 255, 255, 0.1);
            --text-main: #f8fafc;
            --text-muted: #cbd5e1; /* Increased contrast from #94a3b8 */
            --glass-bg: rgba(255, 255, 255, 0.03);
            --gradient-1: linear-gradient(135deg, #6366f1 0%, #a855f7 100%);
            --sidebar-width: 280px;
        }

        body {
            background-color: var(--bg-color);
            background-image: 
                radial-gradient(at 0% 0%, rgba(99, 102, 241, 0.15) 0px, transparent 50%),
                radial-gradient(at 100% 100%, rgba(14, 165, 233, 0.1) 0px, transparent 50%);
            color: var(--text-main);
            font-family: 'Inter', sans-serif;
            min-height: 100vh;
            overflow-x: hidden;
        }

        h1, h2, h3, h4, .dt-brand {
            font-family: 'Outfit', sans-serif;
        }

        /* Sidebar Glassmorphism */
        .dt-sidebar {
            width: var(--sidebar-width);
            background: var(--surface);
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
            border-right: 1px solid var(--border-color);
            z-index: 1040;
            transition: all 0.3s ease;
        }

        .dt-brand {
            padding: 2rem 1.5rem;
            font-size: 1.5rem;
            font-weight: 700;
            background: var(--gradient-1);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .dt-brand i {
            -webkit-text-fill-color: var(--primary);
        }

        .dt-nav {
            padding: 0 1rem;
        }

        .dt-nav .nav-link {
            color: var(--text-muted);
            padding: 0.8rem 1rem;
            border-radius: 12px;
            margin-bottom: 0.25rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            font-weight: 500;
            transition: all 0.2s;
        }

        .dt-nav .nav-link i {
            font-size: 1.25rem;
        }

        .dt-nav .nav-link:hover {
            color: var(--text-main);
            background: var(--glass-bg);
            transform: translateX(4px);
        }

        .dt-nav .nav-link.active {
            color: #fff;
            background: var(--primary);
            box-shadow: 0 4px 12px rgba(99, 102, 241, 0.3);
        }

        .dt-nav-header {
            font-size: 0.75rem;
            font-weight: 700;
            text-transform: uppercase;
            color: var(--text-muted);
            padding: 1.5rem 1rem 0.5rem;
            letter-spacing: 0.1em;
        }

        /* Topbar Luxe */
        .dt-topbar {
            background: rgba(5, 11, 24, 0.6);
            backdrop-filter: blur(8px);
            -webkit-backdrop-filter: blur(8px);
            border-bottom: 1px solid var(--border-color);
            height: 70px;
            padding: 0 2rem;
            z-index: 1030;
        }

        .dt-content {
            padding: 2rem;
        }

        /* Global Contrast Fixes */
        .text-white-force { color: #ffffff !important; }
        .text-main-force { color: var(--text-main) !important; }
        .text-muted-force { color: var(--text-muted) !important; }

        /* Card Styles Reconstruction */
        .card {
            background: rgba(17, 25, 40, 0.6) !important;
            backdrop-filter: blur(16px) !important;
            -webkit-backdrop-filter: blur(16px) !important;
            border: 1px solid var(--border-color) !important;
            border-radius: 20px !important;
            color: var(--text-main) !important;
            overflow: hidden;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        .card:hover {
            transform: translateY(-4px);
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.4);
            border-color: rgba(255, 255, 255, 0.2) !important;
        }

        .card-header {
            background: rgba(255, 255, 255, 0.05) !important;
            border-bottom: 1px solid var(--border-color) !important;
            padding: 1.25rem 1.5rem !important;
            color: #ffffff !important;
            font-weight: 700 !important;
        }

        .card-body {
            color: var(--text-main) !important;
        }

        /* Table Premium Reconstruction */
        .table {
            color: var(--text-main) !important;
            margin-bottom: 0;
            background: transparent !important;
        }

        .table thead th {
            background: rgba(255, 255, 255, 0.08) !important;
            border-bottom: 2px solid var(--border-color) !important;
            color: #ffffff !important;
            font-weight: 700 !important;
            letter-spacing: 0.5px;
            text-transform: uppercase;
            font-size: 0.75rem;
            padding: 1.25rem 1.5rem !important;
        }

        .table tbody td {
            background: transparent !important;
            border-bottom: 1px solid var(--border-color) !important;
            padding: 1.25rem 1.5rem !important;
            vertical-align: middle;
            color: rgba(255, 255, 255, 0.85) !important;
        }

        .table tr:hover td {
            background: rgba(255, 255, 255, 0.03) !important;
            color: #ffffff !important;
        }

        /* Form Visibility Reconstruction */
        .form-control, .form-select {
            background: rgba(255, 255, 255, 0.05) !important;
            border: 1px solid var(--border-color) !important;
            color: #ffffff !important;
            border-radius: 12px !important;
            padding: 0.8rem 1.25rem !important;
        }

        .form-control::placeholder {
            color: rgba(255, 255, 255, 0.4) !important;
        }

        .form-control:focus, .form-select:focus {
            background: rgba(255, 255, 255, 0.1) !important;
            border-color: var(--primary) !important;
            color: #ffffff !important;
            box-shadow: 0 0 0 4px rgba(var(--primary-rgb), 0.2) !important;
        }

        .input-group-text {
            background: rgba(255, 255, 255, 0.1) !important;
            border: 1px solid var(--border-color) !important;
            color: #ffffff !important;
            border-radius: 12px 0 0 12px !important;
        }

        /* Sidebar Footer visibility */
        .dt-user-info-area {
            background: rgba(255, 255, 255, 0.05);
            padding: 1rem;
            border-radius: 15px;
            border: 1px solid rgba(255, 255, 255, 0.05);
        }
        .dt-user-name { color: #ffffff !important; font-weight: 600; }
        .dt-user-role { color: var(--text-muted) !important; font-size: 0.8rem; }

        /* Mobile Sidebar */
        @media (max-width: 991.98px) {
            .dt-sidebar { width: 0; overflow: hidden; position: fixed; }
            .dt-sidebar.show { width: 280px; }
            .dt-content-wrapper { margin-left: 0 !important; }
        }
    </style>
    @stack('styles')
</head>
<body class="text-light">
<div class="d-flex">
    <!-- Sidebar -->
    <aside class="dt-sidebar d-none d-lg-flex flex-column position-fixed top-0 bottom-0">
        <div class="dt-brand">
            <i class="bi bi-mortarboard-fill"></i>
            <span>DiplômeTrack</span>
        </div>
        
        <div class="flex-grow-1 overflow-y-auto">
            <nav class="dt-nav">
                @yield('sidebar')
            </nav>
        </div>

        <div class="p-3 border-top border-white border-opacity-5">
            <div class="d-flex align-items-center gap-3 dt-user-info-area">
                <div class="bg-primary rounded-circle d-flex align-items-center justify-content-center text-white" style="width: 40px; height: 40px;">
                    <i class="bi bi-person-fill"></i>
                </div>
                <div class="overflow-hidden">
                    <div class="dt-user-name text-truncate">Connecté en tant que</div>
                    <div class="dt-user-role text-truncate">@yield('user_role', 'Utilisateur')</div>
                </div>
            </div>
        </div>
    </aside>

    <!-- Main Content -->
    <div class="flex-grow-1 dt-content-wrapper" style="margin-left: var(--sidebar-width);">
        <nav class="navbar dt-topbar navbar-expand-lg px-4 d-flex align-items-center">
            <button class="btn btn-glass d-lg-none me-2" type="button" data-bs-toggle="offcanvas" data-bs-target="#mobileSidebar">
                <i class="bi bi-list"></i>
            </button>
            <div class="d-flex flex-column d-none d-md-flex">
                <div class="xsmall text-muted mb-0 opacity-50">DiplômeTrack / @yield('user_role', 'Utilisateur')</div>
                <div class="h5 mb-0 fw-bold">@yield('page_title', 'Dashboard')</div>
            </div>

            <div class="ms-lg-5 d-none d-lg-block flex-grow-1" style="max-width: 400px;">
                <div class="position-relative">
                    <i class="bi bi-search position-absolute top-50 start-0 translate-middle-y ms-3 text-muted"></i>
                    <input type="text" class="form-control ps-5 bg-white bg-opacity-5 border-white border-opacity-10" placeholder="Rechercher un dossier, un étudiant...">
                </div>
            </div>

            <div class="ms-auto d-flex align-items-center gap-3">
                <div class="dropdown">
                    <button class="btn btn-glass dropdown-toggle d-flex align-items-center gap-2" data-bs-toggle="dropdown">
                        <span class="d-none d-sm-inline">Menu Rapide</span>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end dropdown-menu-dark shadow-lg border-white border-opacity-10">
                        <li><a class="dropdown-item py-2" href="{{ route('admin.profile') }}"><i class="bi bi-person-circle me-2"></i>Mon Profil</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item py-2 text-warning" href="{{ route('student.dashboard') }}"><i class="bi bi-mortarboard me-2"></i>Vue Étudiant</a></li>
                        <li><a class="dropdown-item py-2 text-info" href="{{ route('admin.super.dashboard') }}"><i class="bi bi-speedometer2 me-2"></i>Dashboard Admin</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item py-2 text-danger" href="{{ route('login') }}"><i class="bi bi-box-arrow-right me-2"></i>Déconnexion</a></li>
                    </ul>
                </div>
                
                <div class="vr mx-2 bg-white opacity-10"></div>
                
                <button class="btn btn-glass position-relative">
                    <i class="bi bi-bell"></i>
                    <span class="position-absolute top-0 start-100 translate-middle p-1 bg-danger border border-light rounded-circle"></span>
                </button>
            </div>
        </nav>

        <main class="dt-content">
            @yield('content')
        </main>

        @yield('modals')

        <footer class="dt-footer px-4 py-4 mt-auto border-top border-white border-opacity-5">
            <div class="d-flex flex-column flex-md-row justify-content-between align-items-center gap-3">
                <div class="small text-muted">© 2026 <span class="text-white fw-bold">DiplômeTrack</span>. Système Universitaire de Gestion.</div>
                <div class="d-flex gap-4">
                    <a href="#" class="small text-muted text-decoration-none hover-white">Support</a>
                    <a href="#" class="small text-muted text-decoration-none hover-white">Sécurité</a>
                    <a href="#" class="small text-muted text-decoration-none hover-white">Conditions</a>
                </div>
            </div>
        </footer>
    </div>
</div>

<style>
    .xsmall { font-size: 0.7rem; letter-spacing: 0.5px; text-transform: uppercase; }
    .hover-white:hover { color: #fff !important; }
    .bg-soft-primary { background: rgba(var(--primary-rgb), 0.1); }
</style>

<!-- Mobile Sidebar Offcanvas -->
<div class="offcanvas offcanvas-start text-bg-dark" tabindex="-1" id="mobileSidebar" style="width: 280px;">
    <div class="offcanvas-header border-bottom border-white border-opacity-10">
        <h5 class="offcanvas-title dt-brand p-0">DiplômeTrack</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas"></button>
    </div>
    <div class="offcanvas-body p-0">
        <nav class="dt-nav py-3">
            @yield('sidebar')
        </nav>
    </div>
</div>

<!-- Toast Container -->
<div class="toast-container position-fixed bottom-0 end-0 p-3">
    <div id="dtToast" class="toast align-items-center text-white bg-primary border-0 rounded-3 shadow-lg" role="alert" aria-live="assertive" aria-atomic="true">
        <div class="d-flex">
            <div class="toast-body d-flex align-items-center gap-2">
                <i class="bi bi-info-circle"></i> <span id="toastMsg">Action effectuée avec succès.</span>
            </div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
    function showToast(msg, type = 'primary') {
        const toastEl = document.getElementById('dtToast');
        const toastMsg = document.getElementById('toastMsg');
        toastEl.className = `toast align-items-center text-white bg-${type} border-0 rounded-3 shadow-lg`;
        toastMsg.innerText = msg;
        const toast = new bootstrap.Toast(toastEl);
        toast.show();
    }

    // Global listeners for buttons to feel interactive
    document.addEventListener('click', (e) => {
        if (e.target.closest('.btn-primary') && !e.target.closest('a')) {
            showToast("Enregistrement réussi !");
        }
    });
</script>
@stack('scripts')
</body>
</html>
