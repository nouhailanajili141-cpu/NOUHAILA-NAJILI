<div class="dt-nav-header">Gestion Académique</div>
<a class="nav-link {{ ($active ?? '') === 'dashboard' ? 'active' : '' }}" href="{{ route('admin.super.dashboard') }}">
    <i class="bi bi-speedometer2"></i> Vue d'ensemble
</a>
<a class="nav-link {{ ($active ?? '') === 'students' ? 'active' : '' }}" href="{{ route('admin.students.index') }}">
    <i class="bi bi-people"></i> Étudiants
</a>
<a class="nav-link {{ ($active ?? '') === 'diplomas' ? 'active' : '' }}" href="{{ route('admin.diplomas.index') }}">
    <i class="bi bi-award"></i> Diplômes
</a>
<a class="nav-link {{ ($active ?? '') === 'validation' ? 'active' : '' }}" href="{{ route('admin.students.validation') }}">
    <i class="bi bi-patch-check"></i> Validation
</a>
<a class="nav-link {{ ($active ?? '') === 'status' ? 'active' : '' }}" href="{{ route('admin.diplomas.status') }}">
    <i class="bi bi-activity"></i> Suivi Statut
</a>

<div class="dt-nav-header">Sécurité & Système</div>
<a class="nav-link {{ ($active ?? '') === 'users' ? 'active' : '' }}" href="{{ route('admin.users.index') }}">
    <i class="bi bi-shield-lock"></i> Comptes Agents
</a>
<a class="nav-link {{ ($active ?? '') === 'roles' ? 'active' : '' }}" href="{{ route('admin.roles.index') }}">
    <i class="bi bi-key"></i> Rôles & Accès
</a>
<a class="nav-link {{ ($active ?? '') === 'settings' ? 'active' : '' }}" href="{{ route('app.settings') }}">
    <i class="bi bi-gear"></i> Paramètres
</a>

<a class="nav-link text-danger mt-4" href="{{ route('login') }}">
    <i class="bi bi-box-arrow-right"></i> Déconnexion
</a>
