<div class="dt-nav-header">Espace Étudiant</div>
<a class="nav-link {{ ($active ?? '') === 'dashboard' ? 'active' : '' }}" href="{{ route('student.dashboard') }}">
    <i class="bi bi-grid-1x2"></i> Tableau de bord
</a>
<a class="nav-link {{ ($active ?? '') === 'history' ? 'active' : '' }}" href="{{ route('student.history') }}">
    <i class="bi bi-clock-history"></i> Historique
</a>

<div class="dt-nav-header">Paramètres</div>
<a class="nav-link" href="{{ route('app.settings') }}">
    <i class="bi bi-person-gear"></i> Mon Profil
</a>
<a class="nav-link" href="{{ route('app.support') }}">
    <i class="bi bi-question-circle"></i> Support
</a>
<a class="nav-link text-danger mt-4" href="{{ route('login') }}">
    <i class="bi bi-box-arrow-right"></i> Déconnexion
</a>
