@extends('layouts.panel')

@section('title', 'Connexion Étudiant')

@section('content')
<div class="row justify-content-center align-items-center min-vh-100 bg-light">
    <div class="col-md-5">
        <div class="card shadow-sm border-0 rounded-4">
            <div class="card-body p-5">
                <div class="text-center mb-4">
                    <div class="bg-primary bg-opacity-10 text-primary rounded-circle d-inline-flex justify-content-center align-items-center mb-3" style="width: 60px; height: 60px;">
                        <i class="bi bi-mortarboard-fill h3 mb-0"></i>
                    </div>
                    <h2 class="auth-title text-white">Espace Étudiant</h2>
                    <p class="auth-subtitle text-light">Accédez à votre dossier de diplôme</p>
                </div>

                <form action="{{ route('student.dashboard') }}" method="GET">
                    <!-- Note: method GET used for demo purposes to navigate to dashboard -->
                    <div class="mb-3">
                        <label for="code_apogee" class="form-label fw-semibold text-white">Code Apogée</label>
                        <div class="input-group">
                            <span class="input-group-text bg-light border-end-0"><i class="bi bi-person"></i></span>
                            <input type="text" class="form-control bg-light border-start-0 ps-0" id="code_apogee" name="code_apogee" placeholder="Ex: 15000000" required>
                        </div>
                    </div>

                    <div class="mb-4">
                        <label for="cne" class="form-label fw-semibold">CNE (Mot de passe)</label>
                        <div class="input-group">
                            <span class="input-group-text bg-light border-end-0"><i class="bi bi-key"></i></span>
                            <input type="password" class="form-control bg-light border-start-0 ps-0" id="cne" name="cne" placeholder="Votre Code National de l'Étudiant" required>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary w-100 py-2 rounded-3 fw-bold mb-3">
                        Se connecter
                    </button>
                    
                    <div class="text-center">
                        <a href="{{ route('login') }}" class="text-decoration-none text-muted small"><i class="bi bi-arrow-left me-1"></i> Retour au portail principal</a>
                    </div>
                </form>
            </div>
        </div>
        <div class="text-center mt-4">
            <p class="text-muted small">&copy; {{ date('Y') }} DiplômeTrack. Tous droits réservés.</p>
        </div>
    </div>
</div>
@endsection
