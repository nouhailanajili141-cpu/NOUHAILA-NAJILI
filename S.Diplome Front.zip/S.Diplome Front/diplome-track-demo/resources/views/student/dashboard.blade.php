@extends('layouts.panel')

@section('title', 'Tableau de Bord Étudiant')

@section('sidebar')
    @include('partials.sidebar-student')
@endsection

@section('content')
<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="h3 mb-0 text-white fw-bold">Suivi de mon Diplôme</h2>
            <p class="text-muted mb-0">Consultez l'état actuel de votre parcours diplomant.</p>
        </div>
    </div>

    <!-- Info Étudiant -->
    <div class="card border-0 shadow-sm rounded-4 mb-4 bg-white bg-opacity-5">
        <div class="card-body p-4 d-flex align-items-center gap-3">
            <div class="bg-primary bg-opacity-10 text-primary rounded-circle p-3">
                <i class="bi bi-person-badge-fill h2 mb-0"></i>
            </div>
            <div>
                <h5 class="fw-bold mb-1 text-white">Aymane Jabri</h5>
                <p class="text-muted mb-0 small">
                    <span class="me-3 text-white"><i class="bi bi-mortarboard me-1"></i> Génie Logiciel</span>
                    <span class="me-3 text-white"><i class="bi bi-upc-scan me-1"></i> Apogée: 19012345</span>
                    <span class="text-white"><i class="bi bi-card-text me-1"></i> CNE: R123456789</span>
                </p>
            </div>
        </div>
    </div>

    <div class="row">
        <!-- Statut Principal -->
        <div class="col-lg-4 mb-4">
            <div class="card border-0 shadow-sm rounded-4 h-100">
                <div class="card-body p-4 d-flex flex-column align-items-center text-center justify-content-center">
                    <div class="mb-3">
                        <!-- Statuts possibles: text-warning (en cours), text-success (validé/délivré), text-danger (annulé) -->
                        <div class="d-inline-flex bg-success bg-opacity-10 p-4 rounded-circle">
                            <i class="bi bi-check-circle-fill text-success" style="font-size: 3rem;"></i>
                        </div>
                    </div>
                    <h5 class="fw-bold text-white">Statut actuel</h5>
                    <h2 class="text-success fw-bolder mb-2">Validé</h2>
                    <p class="text-muted small">Vous êtes éligible à l'obtention du diplôme. En attente de délivrance.</p>
                </div>
            </div>
        </div>

        <!-- Dates Clés -->
        <div class="col-lg-8 mb-4">
            <div class="card border-0 shadow-sm rounded-4 h-100">
                <div class="card-header bg-transparent border-bottom-0 pt-4 pb-0 px-4">
                    <h6 class="fw-bold"><i class="bi bi-calendar-event me-2"></i>Dates importantes</h6>
                </div>
                <div class="card-body p-4">
                    <div class="row g-4">
                        <div class="col-md-4">
                            <div class="p-3 border border-white border-opacity-10 rounded-4" style="background: rgba(255,255,255,0.03);">
                                <div class="text-muted small mb-1">Date de demande</div>
                                <div class="fw-bold h5 mb-0 text-white">15 Mai 2026</div>
                                <i class="bi bi-file-earmark-text text-white position-absolute" style="opacity: 0.1; font-size: 3rem; right: 2rem; top: 1rem;"></i>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="p-3 border border-success border-opacity-50 rounded-3 bg-success bg-opacity-10">
                                <div class="text-success small fw-semibold mb-1">Date de validation</div>
                                <div class="fw-bold h5 mb-0 text-success">24 Juin 2026</div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="p-3 border border-white border-opacity-10 rounded-4 opacity-75" style="background: rgba(255,255,255,0.01);">
                                <div class="text-muted small mb-1">Date de remise</div>
                                <div class="fw-bold h5 mb-0 text-muted">À venir</div>
                            </div>
                        </div>
                    </div>

                    <!-- Progress Bar -->
                    <div class="mt-5">
                        <div class="d-flex justify-content-between mb-2 text-muted fw-bold small">
                            <span>Demande</span>
                            <span>Validation</span>
                            <span>Remise</span>
                        </div>
                        <div class="progress rounded-pill" style="height: 10px;">
                            <div class="progress-bar bg-success" role="progressbar" style="width: 66%" aria-valuenow="66" aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
