@extends('layouts.panel')

@section('title', 'Validation des Résultats')

@section('sidebar')
    @include('partials.sidebar-generic', ['active' => 'admin.validation'])
@endsection

@section('content')
<div class="container-fluid py-4">
    <div class="mb-4">
        <h2 class="h3 mb-0 text-white fw-bold">Validation des Résultats</h2>
        <p class="text-muted">Vérifiez l'éligibilité des étudiants et mettez à jour l'état de leurs diplômes.</p>
    </div>

    <!-- Interface Validation -->
    <div class="row">
        <div class="col-lg-12">
    <div class="card border-0 mb-4">
        <div class="card-header">
            <h5 class="fw-bold mb-0 text-white">Dossiers en attente de vérification</h5>
        </div>
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead>
                            <tr>
                                <th class="ps-4">Étudiant</th>
                                <th>Diplôme</th>
                                <th>Résultats Académiques</th>
                                <th>Action/Décision</th>
                            </tr>
                        </thead>
                        <tbody class="border-top-0">
                            <!-- Ligne 1 -->
                            <tr>
                                <td class="ps-4">
                                    <div class="fw-bold text-white">Aymane Jabri</div>
                                    <div class="text-muted small">19012345</div>
                                </td>
                                <td>
                                    <div class="fw-semibold">Licence F. - Génie Logiciel</div>
                                </td>
                                <td>
                                    <span class="badge bg-success bg-opacity-10 text-success border border-success border-opacity-25 px-2 py-1"><i class="bi bi-check-circle me-1"></i> Réussi (Mention: Très Bien)</span>
                                </td>
                                <td>
                                    <div class="d-flex gap-2">
                                        <button class="btn btn-sm btn-success rounded-3"><i class="bi bi-check-lg me-1"></i> Valider le diplôme</button>
                                        <button class="btn btn-sm btn-danger rounded-3 p-2"><i class="bi bi-x-lg"></i></button>
                                    </div>
                                </td>
                            </tr>
                            
                            <!-- Ligne 2 -->
                            <tr>
                                <td class="ps-4">
                                    <div class="fw-bold text-white">Sara Benali</div>
                                    <div class="text-muted small">19054321</div>
                                </td>
                                <td>
                                    <div class="fw-semibold">Master S. - Réseaux</div>
                                </td>
                                <td>
                                    <span class="badge bg-danger bg-opacity-10 text-danger border border-danger border-opacity-25 px-2 py-1"><i class="bi bi-x-circle me-1"></i> Non Validé (Modules restants)</span>
                                </td>
                                <td>
                                    <div class="d-flex gap-2">
                                        <button class="btn btn-sm btn-outline-secondary rounded-3 disabled"><i class="bi bi-check-lg me-1"></i> Valider</button>
                                        <button class="btn btn-sm btn-danger rounded-3"><i class="bi bi-x-lg me-1"></i> Annuler le diplôme</button>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <div class="alert alert-info mt-4 rounded-4 border-0 d-flex align-items-center mb-0">
                <i class="bi bi-info-circle-fill fs-4 me-3"></i>
                <div>
                    <strong>Note:</strong> L'action de validation marque le diplôme comme "Validé" et génère une entrée d'historique automatique (Statut: validé, Date de validation).
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
