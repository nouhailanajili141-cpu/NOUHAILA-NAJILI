@extends('layouts.panel')

@section('title', 'Gestion des Diplômes')

@section('sidebar')
    @include('partials.sidebar-generic', ['active' => 'admin.diplomas'])
@endsection

@section('content')
<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="h3 mb-0 text-white fw-bold">Gestion des Diplômes</h2>
            <p class="text-muted">Créez et associez les diplômes aux étudiants.</p>
        </div>
        <button class="btn btn-primary d-flex align-items-center gap-2 rounded-3 shadow-sm" data-bs-toggle="modal" data-bs-target="#addDiplomaModal">
            <i class="bi bi-award-fill"></i> Nouveau Diplôme
        </button>
    </div>

    <div class="row g-4 mb-4">
        <div class="col-md-4">
            <div class="card border-0 shadow-sm rounded-4 bg-primary bg-opacity-10">
                <div class="card-body p-4 text-center">
                    <h6 class="text-primary fw-bold mb-2">Diplômes en cours</h6>
                    <h2 class="text-primary fw-bolder mb-0">12</h2>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card border-0 shadow-sm rounded-4 bg-success bg-opacity-10">
                <div class="card-body p-4 text-center">
                    <h6 class="text-success fw-bold mb-2">Diplômes Validés</h6>
                    <h2 class="text-success fw-bolder mb-0">85</h2>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card border-0 shadow-sm rounded-4 bg-secondary bg-opacity-10">
                <div class="card-body p-4 text-center">
                    <h6 class="text-secondary fw-bold mb-2">Diplômes Délivrés</h6>
                    <h2 class="text-secondary fw-bolder mb-0">340</h2>
                </div>
            </div>
        </div>
    </div>

    <!-- Table -->
    <div class="card border-0 shadow-sm rounded-4">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead>
                    <tr>
                        <th class="ps-4">Diplôme</th>
                        <th>Spécialité</th>
                        <th>Niveau</th>
                        <th>Étudiant Associé</th>
                        <th>Statut</th>
                        <th class="text-end pe-4">Actions</th>
                    </tr>
                </thead>
                <tbody class="border-top-0">
                    <tr>
                        <td class="ps-4 fw-bold text-white">Licence Fondamentale</td>
                        <td>Génie Logiciel</td>
                        <td>Bac+3</td>
                        <td>Aymane Jabri <span class="text-muted small d-block">19012345</span></td>
                        <td><span class="badge bg-success bg-opacity-10 text-success rounded-pill px-3 py-2 border border-success border-opacity-25">Validé</span></td>
                        <td class="text-end pe-4">
                            <button class="btn btn-sm btn-glass rounded-circle text-primary"><i class="bi bi-pencil"></i></button>
                            <button class="btn btn-sm btn-glass rounded-circle text-danger"><i class="bi bi-trash"></i></button>
                        </td>
                    </tr>
                    <tr>
                        <td class="ps-4 fw-bold text-white">Master Spécialisé</td>
                        <td class="text-white-force">Réseaux & Sécurité</td>
                        <td class="text-white-force">Bac+5</td>
                        <td>Sara Benali <span class="text-muted small d-block">19054321</span></td>
                        <td><span class="badge bg-warning bg-opacity-10 text-warning rounded-pill px-3 py-2 border border-warning border-opacity-25">En cours</span></td>
                        <td class="text-end pe-4">
                            <button class="btn btn-sm btn-glass rounded-circle text-primary"><i class="bi bi-pencil"></i></button>
                            <button class="btn btn-sm btn-glass rounded-circle text-danger"><i class="bi bi-trash"></i></button>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

@endsection

@section('modals')
<!-- Modal Ajout Diplôme -->
<div class="modal fade" id="addDiplomaModal" tabindex="-1" style="z-index: 9999;">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content rounded-4 border-0 shadow-lg bg-dark text-light border border-white border-opacity-10">
            <div class="modal-header border-bottom border-white border-opacity-10 pb-3">
                <h5 class="modal-title fw-bold">Ajouter un Diplôme</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4">
                <form>
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Type de diplôme</label>
                        <select class="form-select shadow-none">
                            <option>Licence Fondamentale</option>
                            <option>Master Spécialisé</option>
                            <option>Diplôme d'Ingénieur</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Spécialité</label>
                        <input type="text" class="form-control" placeholder="Ex: Génie Logiciel" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Niveau d'étude</label>
                        <input type="text" class="form-control" placeholder="Ex: Bac+3" required>
                    </div>
                    <div class="mb-1">
                        <label class="form-label small fw-bold">Étudiant bénéficiaire (Code Apogée)</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="bi bi-search"></i></span>
                            <input type="text" class="form-control" placeholder="Rechercher par code Apogée">
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer border-top border-white border-opacity-10 pt-3 d-flex justify-content-between">
                <button type="button" class="btn btn-glass px-4" data-bs-dismiss="modal">Annuler</button>
                <button type="button" class="btn btn-primary px-4 shadow-lg">Créer & Affecter le diplôme</button>
            </div>
        </div>
    </div>
</div>
@endsection
