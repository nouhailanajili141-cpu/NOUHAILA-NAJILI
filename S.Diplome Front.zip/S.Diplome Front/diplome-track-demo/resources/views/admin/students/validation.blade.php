@extends('layouts.panel')

@section('title', 'Validation des Résultats | Administration')
@section('page_title', 'Vérification d\'Éligibilité')
@section('user_role', 'Administration')

@section('sidebar')
    @include('partials.sidebar-superadmin', ['active' => 'validation'])
@endsection

@section('content')
@php
    $pending = [
        ['apogee' => '21004567', 'name' => 'Sara EL AMRANI', 'major' => 'SMI', 'avg' => 14.25, 'status' => 'Admissible'],
        ['apogee' => '21002341', 'name' => 'Youssef BENSAID', 'major' => 'SMA', 'avg' => 11.80, 'status' => 'Admissible'],
        ['apogee' => '21008892', 'name' => 'Imane OUALI', 'major' => 'SMP', 'avg' => 09.40, 'status' => 'Non Admissible'],
        ['apogee' => '21007712', 'name' => 'Mehdi CHAKIR', 'major' => 'SMI', 'avg' => 12.10, 'status' => 'Admissible'],
    ];
@endphp

<div class="card mb-4">
    <div class="card-body">
        <div class="d-flex align-items-center gap-3">
            <div class="bg-primary bg-opacity-10 p-3 rounded-3">
                <i class="bi bi-patch-check text-primary h3 mb-0"></i>
            </div>
            <div>
                <h5 class="fw-bold mb-1 text-white">Validation des Résultats Académiques</h5>
                <p class="text-muted small mb-0">Vérifiez les notes et validez l'éligibilité pour la délivrance du diplôme.</p>
            </div>
            <div class="ms-auto d-flex gap-2">
                <button class="btn btn-outline-primary btn-sm"><i class="bi bi-file-earmark-arrow-down me-2"></i>Exporter CSV</button>
                <button class="btn btn-primary btn-sm"><i class="bi bi-check-all me-2"></i>Valider la Sélection</button>
            </div>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table align-middle">
                <thead>
                    <tr>
                        <th style="width: 40px;"><input type="checkbox" class="form-check-input"></th>
                        <th>Étudiant (Apogée)</th>
                        <th>Filière</th>
                        <th>Moyenne Générale</th>
                        <th>Décision Système</th>
                        <th class="text-end">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($pending as $p)
                    <tr>
                        <td><input type="checkbox" class="form-check-input"></td>
                        <td>
                            <div class="fw-bold text-white">{{ $p['name'] }}</div>
                            <div class="small text-muted">{{ $p['apogee'] }}</div>
                        </td>
                        <td><span class="badge bg-white bg-opacity-10 text-white border border-white border-opacity-25">{{ $p['major'] }}</span></td>
                        <td>
                            <span class="fw-bold {{ $p['avg'] >= 10 ? 'text-success' : 'text-danger' }}">
                                {{ number_format($p['avg'], 2) }} / 20
                            </span>
                        </td>
                        <td>
                            @if($p['status'] == 'Admissible')
                                <span class="badge bg-success bg-opacity-10 text-success border border-success border-opacity-25 px-2">Admissible</span>
                            @else
                                <span class="badge bg-danger bg-opacity-10 text-danger border border-danger border-opacity-25 px-2">Non Admissible</span>
                            @endif
                        </td>
                        <td class="text-end text-nowrap">
                            <button class="btn btn-glass btn-sm me-1 text-success" title="Approuver"><i class="bi bi-check2-circle"></i></button>
                            <button class="btn btn-glass btn-sm text-danger" title="Rejeter"><i class="bi bi-x-circle"></i></button>
                            <button class="btn btn-glass btn-sm ms-3" title="Voir Relevé"><i class="bi bi-file-text"></i></button>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection
