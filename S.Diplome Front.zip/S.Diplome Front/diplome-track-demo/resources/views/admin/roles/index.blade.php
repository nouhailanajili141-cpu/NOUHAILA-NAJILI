@extends('layouts.panel')

@section('title', 'Gestion des Rôles')

@section('sidebar')
    @include('partials.sidebar-superadmin', ['active' => 'admin.roles'])
@endsection

@section('content')
<div class="container-fluid py-4">
    <div class="mb-4">
        <h2 class="h3 mb-0 text-white fw-bold">Gestion des Rôles & Permissions</h2>
        <p class="text-muted">Définissez ce que chaque type d'utilisateur est autorisé à faire.</p>
    </div>

    <div class="row g-4">
        <!-- Rôle SuperAdmin -->
        <div class="col-md-4">
            <div class="card border-0 shadow-sm rounded-4 h-100 border-top border-danger border-4">
                <div class="card-body p-4 text-center">
                    <div class="bg-danger bg-opacity-10 text-danger rounded-circle d-inline-flex justify-content-center align-items-center mb-3" style="width: 60px; height: 60px;">
                        <i class="bi bi-shield-lock-fill h3 mb-0"></i>
                    </div>
                    <h5 class="fw-bold text-white">Administrateur Système</h5>
                    <p class="text-muted small mb-4">Accès total à la plateforme. Gestion des utilisateurs, des configurations globales et des rôles.</p>
                    
                    <ul class="list-unstyled text-start small text-muted mb-4">
                        <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i> Création d'utilisateurs</li>
                        <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i> Modification des rôles</li>
                        <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i> Accès à tous les modules</li>
                    </ul>

                    <button class="btn btn-outline-danger w-100 rounded-3">Gérer les permissions</button>
                </div>
            </div>
        </div>

        <!-- Rôle Administration -->
        <div class="col-md-4">
            <div class="card border-0 shadow-sm rounded-4 h-100 border-top border-warning border-4">
                <div class="card-body p-4 text-center">
                    <div class="bg-warning bg-opacity-10 text-warning rounded-circle d-inline-flex justify-content-center align-items-center mb-3" style="width: 60px; height: 60px;">
                        <i class="bi bi-building-fill-lock h3 mb-0"></i>
                    </div>
                    <h5 class="fw-bold text-white">Service Scolarité</h5>
                    <p class="text-muted small mb-4">Gestion des étudiants, validation des résultats et délivrance numérique des diplômes.</p>
                    
                    <ul class="list-unstyled text-start small text-muted mb-4">
                        <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i> CRUD Étudiants</li>
                        <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i> Validation des diplômes</li>
                        <li class="mb-2"><i class="bi bi-x-circle-fill text-danger text-opacity-50 me-2"></i> Gestion des configurations</li>
                    </ul>

                    <button class="btn btn-outline-warning text-dark w-100 rounded-3">Gérer les permissions</button>
                </div>
            </div>
        </div>

        <!-- Rôle Étudiant -->
        <div class="col-md-4">
            <div class="card border-0 shadow-sm rounded-4 h-100 border-top border-primary border-4">
                <div class="card-body p-4 text-center">
                    <div class="bg-primary bg-opacity-10 text-primary rounded-circle d-inline-flex justify-content-center align-items-center mb-3" style="width: 60px; height: 60px;">
                        <i class="bi bi-mortarboard-fill h3 mb-0"></i>
                    </div>
                    <h5 class="fw-bold text-white">Étudiant</h5>
                    <p class="text-muted small mb-4">Accès en lecture seule à son propre dossier, suivi de l'état du diplôme et téléchargement (si délivré).</p>
                    
                    <ul class="list-unstyled text-start small text-muted mb-4">
                        <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i> Suivi d'état diplôme</li>
                        <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i> Consultation de l'historique</li>
                        <li class="mb-2"><i class="bi bi-x-circle-fill text-danger text-opacity-50 me-2"></i> Modification des données</li>
                    </ul>

                    <button class="btn btn-outline-primary w-100 rounded-3">Gérer les permissions</button>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
